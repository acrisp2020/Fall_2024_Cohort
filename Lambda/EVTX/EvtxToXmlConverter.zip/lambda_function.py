import boto3
import os
from Evtx.Evtx import Evtx  # Importing the correct class

s3 = boto3.client('s3')

def lambda_handler(event, context):
    # Get the bucket and key from the S3 event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    # Download the .evtx file
    download_path = '/tmp/{}'.format(key.split('/')[-1])
    s3.download_file(bucket, key, download_path)
    
    # Process .evtx file and convert to XML
    logs_content = ""
    with Evtx(download_path) as evtx_file:
        for record in evtx_file.records():
            xml_content = record.xml().replace('\n', '').replace('\r', '')  # Remove internal newlines
            # Decode HTML entities
            xml_content = xml_content.replace('&gt;', '>').replace('&lt;', '<')
            logs_content += xml_content + "\n"  # Add newline after the closing </Event> tag for each log
    
    # Upload XML file back to S3
    xml_key = key.replace('.evtx', '.txt')
    xml_path = '/tmp/{}'.format(xml_key.split('/')[-1])
    with open(xml_path, 'w') as xml_file:
        xml_file.write(logs_content)
    
    s3.upload_file(xml_path, bucket, xml_key)
    
    return {
        'statusCode': 200,
        'body': 'Conversion and upload completed successfully.'
    }
