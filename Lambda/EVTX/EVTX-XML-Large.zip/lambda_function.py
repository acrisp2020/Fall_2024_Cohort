import boto3
import os
import json  # Import json for serializing the payload
from Evtx.Evtx import Evtx  # Importing the correct class

s3 = boto3.client('s3')
lambda_client = boto3.client('lambda')

def lambda_handler(event, context):
    # Get the bucket and key from the S3 event or custom invocation
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    # Start index for chunking (if provided, otherwise start from 0)
    start_index = event.get('start_index', 0)
    chunk_size = 1000  # Process 1000 events at a time
    
    # Download the .evtx file
    download_path = '/tmp/{}'.format(key.split('/')[-1])
    s3.download_file(bucket, key, download_path)
    
    # Process .evtx file in chunks
    logs_content = ""
    end_index = start_index + chunk_size
    
    with Evtx(download_path) as evtx_file:
        records = list(evtx_file.records())
        
        # Get the chunk of events to process
        records_to_process = records[start_index:end_index]
        
        for record in records_to_process:
            xml_content = record.xml().replace('\n', '').replace('\r', '')  # Remove internal newlines
            xml_content = xml_content.replace('&gt;', '>').replace('&lt;', '<')  # Decode HTML entities
            logs_content += xml_content + "\n"  # Add newline after the closing </Event> tag for each log
    
    # Save processed chunk to a temporary file
    chunk_key = key.replace('.evtx', f'_part_{start_index // chunk_size + 1}.txt')
    xml_path = '/tmp/{}'.format(chunk_key.split('/')[-1])
    with open(xml_path, 'w') as xml_file:
        xml_file.write(logs_content)
    
    # Upload the processed chunk to S3
    s3.upload_file(xml_path, bucket, chunk_key)
    
    # If there are more records to process, reinvoke the Lambda function
    if end_index < len(records):
        # Correctly serialize the payload using json.dumps
        lambda_client.invoke(
            FunctionName=context.function_name,
            InvocationType='Event',  # Asynchronous invocation
            Payload=json.dumps({  # Use json.dumps to ensure proper JSON format
                'start_index': end_index,
                'Records': event['Records']  # Pass the original bucket and key for the next invocation
            })
        )
    
    return {
        'statusCode': 200,
        'body': f'Processed events {start_index} to {end_index} and uploaded part {start_index // chunk_size + 1}.'
    }
